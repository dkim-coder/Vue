package com.ssafy.live.ai;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.document.Document;
import org.springframework.ai.evaluation.EvaluationRequest;
import org.springframework.ai.evaluation.EvaluationResponse;
import org.springframework.ai.evaluation.RelevancyEvaluator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AiEvaluation {
    Document d;
    
    @Autowired
    ChatModel model;

    @Autowired
    @Qualifier("simpleChatClient")
    ChatClient simpleChatClient;

    @Test
    void testEvaluation() {

        String userText = "대한민국의 산 중에서 가장 높은 산은?";

        ChatResponse response = simpleChatClient.prompt()
                //.advisors(new QuestionAnswerAdvisor(vectorStore))
                .user(userText)
                .call()
                .chatResponse();
        String responseContent = response.getResult().getOutput().getText();

        var relevancyEvaluator = new RelevancyEvaluator(ChatClient.builder(model));

        EvaluationRequest evaluationRequest = new EvaluationRequest(userText,
                responseContent);

        System.out.println("-----------------------------");
        EvaluationResponse evaluationResponse = relevancyEvaluator.evaluate(evaluationRequest);
        System.out.println(responseContent);
        System.out.println(evaluationResponse.getScore());
        System.out.println(evaluationResponse.getFeedback());
        System.out.println(evaluationResponse.getMetadata());
        assertTrue(evaluationResponse.isPass(), "Response is not relevant to the question");

    }

}
