package com.ssafy.live.ai.rag;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.junit.jupiter.api.Test;
import org.springframework.ai.chat.client.ChatClient.AdvisorSpec;
import org.springframework.ai.chat.client.advisor.QuestionAnswerAdvisor;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.ai.vectorstore.filter.Filter.Expression;
import org.springframework.ai.vectorstore.filter.FilterExpressionBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ssafy.live.ai.service.AiChatService;

import lombok.extern.slf4j.Slf4j;

@SpringBootTest
@Slf4j
public class UseSimpleTxtTest {

    @Autowired
    VectorStore store;

    @Autowired
    AiChatService chatService;

    @Autowired
    ChatModel model;

    // category에 해당하는 데이터 초기화
    void clearStore(String category) {
        store.delete("category == '" + category + "'");
    }

    @Test
    public void simpleTextTest() {
        clearStore("simple");
        List<Document> documents = List.of(
                new Document("The Spring AI project aims to streamline the development of applications that incorporate artificial intelligence functionality without unnecessary complexity",
                        Map.of("category", "simple", "meta_txt", "hong", "meta_num", 2000)),
                new Document("Spring AI provides abstractions that serve as the foundation for developing AI applications. ", Map.of("category", "simple", "meta_txt", "jang", "meta_num", 2001)),
                new Document("Spring is new beginning", Map.of("category", "simple", "meta_num", 2001)));

        // VectorStore에 데이터 저장하기
        store.add(documents);

        var searchRequestBuilder = SearchRequest.builder().query("Spring").topK(3).similarityThreshold(0.75);
        List<Document> result1 = store.similaritySearch(searchRequestBuilder.build());

        log.debug("no filter: {}", result1.size());
        result1.forEach(doc -> System.out.println(doc));

        FilterExpressionBuilder builder = new FilterExpressionBuilder();
        Expression expression = builder.and(builder.eq("category", "simple"), builder.and(builder.in("meta_txt", "hong", "jang"), builder.gte("meta_num", 2000))).build();

        List<Document> result2 = store.similaritySearch(searchRequestBuilder.filterExpression(expression).build());

        log.debug("use expression filter: {}", result2.size());
        result2.forEach(doc -> System.out.println(doc));

        String strExpression = "category=='simple' && meta_txt in ['hong','jang'] && meta_num>=2000";
        List<Document> result3 = store.similaritySearch(searchRequestBuilder.filterExpression(strExpression).build());

        log.debug("use string filter: {}", result3.size());
        result3.forEach(doc -> System.out.println(doc));
    }

    @Test
    void simpleTest1() {
        String user = "Spring AI와 관련된 내용을 자세히 알려줘";
        Consumer<AdvisorSpec> spec = a -> a.param(QuestionAnswerAdvisor.FILTER_EXPRESSION, "category=='simple'");
        String r1 = chatService.ragGeneration(user, true, spec); // 3건
        log.debug("r1: {}", r1);
    }

    @Test
    void simpleTest2() {
        String user = "Spring AI와 관련된 내용을 자세히 알려줘";
        Consumer<AdvisorSpec> spec = a -> a.param(QuestionAnswerAdvisor.FILTER_EXPRESSION, "category=='simple'");
        String r1 = chatService.ragGeneration(user, false, spec); // 3건
        log.debug("r1: {}", r1);
    }

    @Test
    void simpleTest3() {
        String user = "Spring AI와 관련된 내용을 자세히 알려줘";
        Consumer<AdvisorSpec> spec = a -> a.param(QuestionAnswerAdvisor.FILTER_EXPRESSION, "meta_num>=3000 && category=='simple'");
        String r1 = chatService.ragGeneration(user, true, spec); // 0건
        log.debug("r1: {}", r1);
    }

    @Test
    void simpleTest4() {
        String user = "Spring AI와 관련된 내용을 자세히 알려줘";
        Consumer<AdvisorSpec> spec = a -> a.param(QuestionAnswerAdvisor.FILTER_EXPRESSION, "meta_num>=3000 && category=='simple'");
        String r1 = chatService.ragGeneration(user, false, spec); // 0건
        log.debug("r1: {}", r1);
    }

}
