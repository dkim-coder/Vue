package com.ssafy.live.ai.tools;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Component
@RequiredArgsConstructor
@Slf4j
public class DateTimeTools {

    @Tool(description = "사용자의 timezone에 해당하는 현재의 날짜와 시간 정보를 가져온다.")
    String getCurrentDateTime() {
        return LocalDateTime.now().toString();
    }

    @Tool(description = "주어진 시간에 알람을 설정한다.")
    void setAlarm(@ToolParam(description = "알람을 울릴 시간") LocalDateTime alarmTime) {
        String osName = System.getProperty("os.name").toLowerCase();
        try {
            setAlarm(alarmTime, osName);
            log.debug("{}에 알람이 설정되었습니다.", alarmTime);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setAlarm(LocalDateTime alarmTime, String osName) throws IOException, InterruptedException {
        // 현재 시간과 알람 시간 사이의 초 계산
        LocalDateTime now = LocalDateTime.now();
        Duration duration = Duration.between(now, alarmTime);
        long seconds = duration.getSeconds();

        // Mac OS에서의 알람 설정
        String[] macScript = {
                "osascript",
                "-e",
                "do shell script \"sleep " + seconds +
                      " && afplay /System/Library/Sounds/Glass.aiff && osascript -e 'display notification \\\"알람 시간입니다!\\\" with title \\\"알람\\\" sound name \\\"Glass\\\"' &\""
        };
        // Window OS에서의 알람 설정
        String taskName = "AlarmAt" + alarmTime.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String time = alarmTime.format(DateTimeFormatter.ofPattern("HH:mm"));

        String[] windowScript = {
                "cmd.exe",
                "/c",
                "schtasks /create /tn \"" + taskName + "\" /tr \"msg %username% 알람 시간입니다!\" /sc once /st " + time
        };

        if (osName.contains("mac")) {
            Runtime.getRuntime().exec(macScript);
        } else if (osName.contains("win")) {
            System.out.println("win");
            System.out.println(Arrays.toString(windowScript));
            Runtime.getRuntime().exec(windowScript);
        } else {
            throw new RuntimeException("Unsupported operating system: " + osName + ". Alarm set for " + alarmTime);
        }
        System.out.println("알람이 " + alarmTime.format(DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 HH시 mm분 ss초")) + "에 설정되었습니다");
    }

}
