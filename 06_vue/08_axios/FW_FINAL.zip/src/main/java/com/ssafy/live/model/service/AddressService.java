package com.ssafy.live.model.service;

import com.ssafy.live.model.dto.Address;

public interface AddressService {
    public void registAddress(Address address);

    public void deleteAddress(int ano);
}
