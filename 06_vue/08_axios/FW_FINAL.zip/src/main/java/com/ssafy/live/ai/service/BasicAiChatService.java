package com.ssafy.live.ai.service;

import java.util.Map;
import java.util.function.Consumer;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.ChatClient.AdvisorSpec;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeType;

import com.ssafy.live.ai.tools.DateTimeTools;
import com.ssafy.live.ai.tools.MemberTools;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
@RequiredArgsConstructor
public class BasicAiChatService implements AiChatService {

    private final ChatModel model2;
    @Qualifier("simpleChatClient")
    private final ChatClient simpleChatClient;

    public Object simpleGeneration(String userInput) {
        var spec = simpleChatClient.prompt()// fluent api 형태로 user, system 등 prompt 파트 구성
                .system(t -> t.param("language", "korean")
                        .param("character", "chill"))// system prompt 구
                .user(userInput)// // user 메시지 전달
                .call(); // 실제 모델 호출
        return spec.content();
    }

    public Quiz quiz(String category) {
        PromptTemplate pt = new PromptTemplate("""
                "{category}와 관련된 재밋는 퀴즈 내봐.
                퀴즈는 내용(question), 정답(answer), 이유(reason)이 필요해."
                """);// 타입에 대한 적절한 유도 필요

        Prompt prompt = pt.create(Map.of("category", category));
        return simpleChatClient.prompt(prompt)
                .system(c -> c.param("language", "Korean").param("character", "유머스러운"))
                .call().entity(new ParameterizedTypeReference<Quiz>() {
                });
    }

    public String multiModal(String userInput, MimeType mime, Resource resource) {
        return this.simpleChatClient.prompt().system(c -> c.param("language", "Korean").param("character", "Chill한"))
                .user(spec -> {
                    spec.media(mime, resource).text(userInput);
                }).call().content();
    }

    @Qualifier("reReadingChatClient")
    private final ChatClient reReadingChatClient;

    @Override
    public String reReadingGeneration(String userInput) {
        return this.reReadingChatClient.prompt() // fluent api 형태로 user, system 등 prompt 파트 구성
                .system(c -> c.param("language", "Korean").param("character", "귀여운"))
                .user(userInput)// user 메시지 전달
                .call() // model 호출
                .content(); // 응답의 내용을 단순한 문자열로 반환
    }

    @Qualifier("advisedChatClient")
    private final ChatClient advisedChatClient;

    @Override
    public String advisedGeneration(String userInput) {
        return this.advisedChatClient.prompt() // fluent api 형태로 user, system 등 prompt 파트 구성
                .system(c -> c.param("language", "Korean").param("character", "Chill한")).user(userInput)// user 메시지 전달
                .call() // model 호출
                .content(); // 응답의 내용을 단순한 문자열로 반환
    }

    private final DateTimeTools dateTimeTools;

    @Override
    public String timeToolGeneration(String userInput) {
        return this.advisedChatClient.prompt().system(c -> c.param("language", "Korean").param("character", "Chill한"))
                .user(userInput).tools(dateTimeTools).call().content();
    }

    private final MemberTools memberTools;

    @Override
    public String memberToolGeneration(String userInput) {
        return this.advisedChatClient.prompt().system(c -> c.param("language", "Korean").param("character", "Chill한"))
                .user(userInput).tools(memberTools).call().content();
    }

    @Qualifier("ragChatDefaultClient")
    private final ChatClient ragChatDefaultClient;

    @Qualifier("ragChatCustomClient")
    private final ChatClient ragChatCustomClient;

    @Override
    public String ragGeneration(String userInput, boolean contextOnly, Consumer<AdvisorSpec> advisorSpec) {
        ChatClient chatClient = contextOnly ? ragChatDefaultClient : ragChatCustomClient;
        var spec = chatClient.prompt()
                .system(c -> c.param("language", "Korean").param("character", "Chill한"))
                .user(userInput);
        if (advisorSpec != null) {
            spec.advisors(advisorSpec);
        }
        return spec.call().content();
    }
}
