<template>
  <div class="container">
    MainView

    <div v-if="data">
      {{ data }}
    </div>
    <div v-else-if="error">
      {{ error }}
    </div>
    <div v-else>잠시만요~~</div>
  </div>
</template>

<script setup>
const getTodoOld = async () => {
  try {
    const response = await fetch('http://localhost:8080/api/v1/members/admin@ssafy.com')
    const json = await response.json()
    console.log('fetch', json)
  } catch (e) {
    console.log(e)
  }
}
getTodoOld()

// TODO: 01. 기존의 fetch style을 axios style로 변경해보자.

// END
</script>

<style lang="scss" scoped></style>
