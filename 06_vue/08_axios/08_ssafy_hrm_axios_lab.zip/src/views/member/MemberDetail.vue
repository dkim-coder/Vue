<template>
  <div class="container mt-5">
    <div class="row">
      <MemberDetailInfo :member="member" @profile-update="profileUpdate" />
      <MemberDetailAddress :member="member" @address-update="addressUpdate" />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import MemberDetailInfo from '@/components/member/MemberDetailInfo.vue'
import MemberDetailAddress from '@/components/member/MemberDetailAddress.vue'

const member = ref({})

const addressUpdate = (addresses) => {
  member.value.addresses = addresses
}
const profileUpdate = (profile) => {
  member.value.profile = profile
}
import { useRoute, onBeforeRouteUpdate } from 'vue-router'
const route = useRoute()
console.log(route.params)

// TODO: 03-1. 회원의 상세 정보를 조회해보자. /api/v1/members/{email}

// END

onBeforeRouteUpdate((to) => {
  // TODO: 03-2. 경로 변경 시 파라미터를 이용해서 새로운 사용자 정보를 설정하도록 처리하자.
   console.log(to.path, '=>', from.path)

  // END
})
</script>

<style scoped></style>
