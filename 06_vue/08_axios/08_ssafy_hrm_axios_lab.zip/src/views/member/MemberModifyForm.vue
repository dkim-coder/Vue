<template>
  <div class="container">
    <h1>회원수정</h1>
    <form action="${root}/auth/member-modify" method="post" class="m-3">
      <input type="hidden" name="mno" v-model="member.mno" />

      <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">이름</label>
        <div class="col-sm-10">
          <input
            type="text"
            name="name"
            id="name"
            class="form-control"
            required
            v-model="member.name"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="email" class="col-sm-2 col-form-label">이메일</label>
        <div class="col-sm-10">
          <input
            type="email"
            name="email"
            id="email"
            class="form-control"
            readonly
            v-model="member.email"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">비밀번호</label>
        <div class="col-sm-10">
          <input
            type="password"
            name="password"
            id="password"
            class="form-control"
            required
            v-model="member.password"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">권한</label>
        <div class="col-sm-10">
          <input type="text" name="role" id="role" class="form-control" v-model="member.role" />
        </div>
      </div>

      <button type="submit" class="btn btn-primary" @click.prevent="modifyMember">수정</button>
    </form>

    <div class="alert alert-danger" role="alert" v-if="error">{{ error }}</div>
  </div>
</template>

<script setup>
import { ref, inject } from 'vue'

const member = ref({})
const globalStatus = inject('globalStatus')
const error = ref('')
import { useRoute, useRouter } from 'vue-router'
const route = useRoute()
const router = useRouter()
console.log('member modify form', route.params)
//TODO: 04-1. 전달된 parameter를 이용해서 사용자 정보를 조회해서 설정한다.

//END

const modifyMember = async () => {
  // TODO: 04-2. 회원 정보를 수정하고 성공하면 memberDetail로 이동한다.
alert('수정되었습니다.')
router.push({ name: 'memberDetail', params: { email: member.value.email } })

  // END
}
</script>

<style lang="scss" scoped></style>
