<template>
  <div class="col-md-7">
    <div class="card">
      <div class="card-header">
        <h4>주소 정보</h4>
      </div>
      <div class="card-body">
        <table class="table table-bordered" id="table-user-address">
          <thead>
            <tr>
              <th>주소 제목</th>
              <th>주소</th>
              <th>상세 주소</th>
              <th>편집</th>
            </tr>
          </thead>
          <tbody id="address-body">
            <tr v-for="(item, idx) in member.addresses" :key="idx">
              <td>{{ item.title }}</td>
              <td>{{ item.address }}</td>
              <td>{{ item.detailAddress }}</td>
              <td>
                <button class="btn btn-danger" @click="deleteAddress(item.ano)">삭제</button>
              </td>
            </tr>
          </tbody>
        </table>
        <MemberDetailAddressMap :member="member" />
        <hr />
        <form id="formAddressAdd">
          <fieldset class="row g-3">
            <!-- address 등록용 -->
            <input type="hidden" name="mno" :value="member.mno" />
            <!-- member detail 조회용 -->
            <input type="hidden" name="email" :value="member.email" />
            <input type="hidden" name="x" id="x" />
            <input type="hidden" name="y" id="y" />
            <div class="col-md-2">
              <label for="addr_title" class="form-label">제목</label>
              <input
                type="text"
                class="form-control"
                id="title"
                name="title"
                required
                v-model="address.title"
              />
            </div>
            <div class="col-md-5">
              <label for="addr_main" class="form-label">주소</label>
              <input
                type="text"
                class="form-control"
                id="address"
                name="address"
                required
                v-model="address.address"
              />
            </div>
            <div class="col-md-5">
              <label for="addr_detail" class="form-label">상세주소</label>
              <input
                type="text"
                class="form-control"
                id="detailAddress"
                name="detailAddress"
                required
                v-model="address.detailAddress"
              />
            </div>
            <div class="col-12 text-end">
              <button
                type="button"
                class="btn btn-primary"
                :data-mno="member.mno"
                id="btn-address-add"
                @click="addressInsert"
              >
                추가
              </button>
            </div>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
  <div class="alert alert-danger" role="alert" v-if="error">{{ error }}</div>
</template>

<script setup>
import { ref } from 'vue'
const props = defineProps({
  member: Object,
})
import MemberDetailAddressMap from '@/components/member/MemberDetailAddressMap.vue'
const error = ref('')
const address = ref({
  title: '테스트',
  address: '경상북도 울릉군 울릉읍',
  detailAddress: '독도 안용복길 3',
})

// 단방향의 흐름을 만들기 위해서 수정 처리는 부모 컴포넌트에서 처리하도록 한다.
// props로 전달된 member를 수정하는 것이 아니라, 부모 컴포넌트에서 수정할 수 있도록 이벤트를 발생시킨다.

const emit = defineEmits(['address-update'])
// TODO: 06-1. address를 삭제한 후 상위 컴포넌트에 address-update를 발생시키세요.
const deleteAddress = (ano) => {
  if (confirm('정말 삭제하시겠습니까?')) {
    emit('address-update', props.member.addresses)
  }

// END

// TODO: 06-2. 다음 링크를 참조하여 주소를 경위도로 반환해보자.
//  memberAi외에 별도의 instance를 생성해서 사용하자.
// https://developers.kakao.com/docs/latest/ko/local/dev-guide#address-coord
