<template>
  <AppHeader />
  <!--TODO: 03. routing 되는 component가 표시된 영역을 선언하세요.-->

  <!--END-->
  <AppFooter />
</template>
<script setup>
import AppFooter from '@/components/common/AppFooter.vue'
import AppHeader from '@/components/common/AppHeader.vue'
</script>

<style scoped></style>
