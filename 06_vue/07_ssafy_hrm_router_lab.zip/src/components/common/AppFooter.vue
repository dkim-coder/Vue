<template>
  <div class="container">
    <hr />
    <div class="text-center">since 2025.01 ver Vue Component</div>
  </div>
</template>

<script setup></script>

<style scoped></style>
