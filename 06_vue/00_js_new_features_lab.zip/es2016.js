console.log(2 ** 3);
const arr = "Hello".split("");
console.log(arr);
console.log(arr.includes("H"));
