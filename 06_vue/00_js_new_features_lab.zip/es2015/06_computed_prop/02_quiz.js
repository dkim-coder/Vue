// quiz 01.
// const ACTION_PREFIX = "FETCH_DATA"
// const actionStatus = {
//   [`${ACTION_PREFIX}_PENDING`]: "pending",
//   [`${ACTION_PREFIX}_SUCCESS`]: "success",
//   type: "IO", // 일반 속성
// }
// console.log(actionStatus.FETCH_DATA_PENDING)

// quiz 02.
// const env = "production" // 현재 환경
// const config = {
//   version: "1.0",
//   [`${env}_url`]: "https://prod.example.com",
// }

// console.log(Object.keys(config).includes("production_url"))
