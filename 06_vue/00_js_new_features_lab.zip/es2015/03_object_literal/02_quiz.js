// quiz 01.
// const title = "watch";
// const version = "1.1";

// const packageInfo = {
//   title,
//   version,
//   printDetails() {
//     console.log(`Package: ${title}, Version: ${version}`);
//   },
// };

// packageInfo.printDetails();
// console.log(packageInfo.version);

// quiz 02.
// let category = "electronics";
// let stock = 50;

// try {
//   const product = {
//     category,
//     price,
//     stock,
//   };
//   console.log(product.category);
// } catch (e) {
//   console.log(e.name);
// }
