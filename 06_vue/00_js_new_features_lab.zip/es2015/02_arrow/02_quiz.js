// quiz 01.
// const createConfig = (port) => {
//   host: "localhost",
//   port: port,
// };

// const config = createConfig(8080);
// console.log(config);

// quiz 02.
// const result = ((x) => x * x)(5);

// console.log(result);
