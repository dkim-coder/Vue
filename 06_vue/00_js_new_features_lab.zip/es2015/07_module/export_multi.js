let addr = "seoul";
let age = 30;
export { addr, age };

export let name = "홍길동";
export function add(a, b) {
  return a + b;
}
