export default {
  sayHello: {
    kor(name) {
      console.log(`안녕 ${name}`);
    },
    eng(name) {
      console.log(`Hello ${name}`);
    },
  },
  sayHi() {
    console.log("Hi");
  },
};
