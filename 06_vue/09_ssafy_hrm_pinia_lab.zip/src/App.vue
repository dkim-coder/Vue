<template>
  <AppHeader />
  <AppLoading />
  <RouterView />
  <AppFooter />
</template>
<script setup>
import AppFooter from '@/components/common/AppFooter.vue'
import AppHeader from '@/components/common/AppHeader.vue'
import AppLoading from '@/components/common/AppLoading.vue'
</script>

<style scoped></style>
