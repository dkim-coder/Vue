// TODO: 02. globalStatus에서 관리하던 isLogin, loginUser를 관리하는 store를 만들어보자.
//  상태를 반환하는 getter와 상태를 변경하는 login, logout action까지 작성해본다.

// END
