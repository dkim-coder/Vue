// index.js
import axios from 'axios'

const memberAi = axios.create({
  baseURL: 'http://localhost:8080',
  timeout: 1000,
})

memberAi.interceptors.request.use(
  async (config) => {
    console.log('[요청 발신]: ', config.method, config.url, config.data)
    handleTask(true)
    return config
  },
  (error) => {
    console.log('[요청 실패]: ', error)
    return Promise.reject(error)
  },
)

memberAi.interceptors.response.use(
  (response) => {
    console.log('[응답 수신]: ', response.status, response.data)
    handleTask(false)
    return response
  },
  async (error) => {
    console.log('[오류 수신]: ', error)
    return Promise.reject(error)
  },
)

const memberAiNoAuth = axios.create({
  baseURL: 'http://localhost:8080',
  timeout: 1000,
})

memberAiNoAuth.interceptors.request.use(
  async (config) => {
    console.log('[요청 발신]: ', config.method, config.url, config.data)
    handleTask(true)
    return config
  },
  (error) => {
    console.log('[요청 실패]: ', error)
    return Promise.reject(error)
  },
)

memberAiNoAuth.interceptors.response.use(
  (response) => {
    console.log('[응답 수신]: ', response.status, response.data)
    handleTask(false)
    return response
  },
  async (error) => {
    console.log('[오류 수신]: ', error)
    handleTask(false)
    return Promise.reject(error)
  },
)
// TODO: 04-3. 작업이 진행되거나 종료될 때 commonStore의 addTask, removeTask를 호출해주자.

// END
export { memberAi, memberAiNoAuth }
