import { createRouter, createWebHistory } from 'vue-router'

import MainView from '@/views/MainView.vue'
import LoginForm from '@/views/member/LoginForm.vue'
import MemberRegistForm from '@/views/member/MemberRegistForm.vue'
import MemberList from '@/views/member/MemberList.vue'
import MemberDetail from '@/views/member/MemberDetail.vue'
import MemberModifyForm from '@/views/member/MemberModifyForm.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: MainView,
    },
    {
      path: '/member',
      children: [
        {
          path: 'login-form',
          name: 'loginForm',
          component: LoginForm,
        },
        {
          path: 'regist-member-form',
          name: 'registMemberForm',
          component: MemberRegistForm,
        },
      ],
    },
    {
      path: '/auth',
      meta: { requireAuth: true },
      children: [
        {
          path: 'member-list',
          name: 'memberList',
          component: MemberList,
        },
        {
          path: 'member-detail/:email',
          name: 'memberDetail',
          component: MemberDetail,
        },
        {
          path: 'member-modify-form/:email',
          name: 'memberModifyForm',
          component: MemberModifyForm,
        },
      ],
    },
  ],
})

// TODO: 03-7. 다음을 memberStore로 변경하세요.
import { inject } from 'vue'
router.beforeEach((to) => {
  const isLoggedIn = inject('globalStatus').value.isLoggedIn
  if (to.meta.requireAuth && !isLoggedIn) {
    return { name: 'loginForm', query: { to: to.path } }
  }
})

// END
export default router
