<template>
  <div class="container">
    <h1>회원수정</h1>
    <form action="${root}/auth/member-modify" method="post" class="m-3">
      <input type="hidden" name="mno" v-model="member.mno" />

      <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">이름</label>
        <div class="col-sm-10">
          <input
            type="text"
            name="name"
            id="name"
            class="form-control"
            required
            v-model="member.name"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="email" class="col-sm-2 col-form-label">이메일</label>
        <div class="col-sm-10">
          <input
            type="email"
            name="email"
            id="email"
            class="form-control"
            readonly
            v-model="member.email"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">비밀번호</label>
        <div class="col-sm-10">
          <input
            type="password"
            name="password"
            id="password"
            class="form-control"
            required
            v-model="member.password"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">권한</label>
        <div class="col-sm-10">
          <input type="text" name="role" id="role" class="form-control" v-model="member.role" />
        </div>
      </div>

      <button type="submit" class="btn btn-primary" @click.prevent="modifyMember">수정</button>
    </form>

    <div class="alert alert-danger" role="alert" v-if="error">{{ error }}</div>
  </div>
</template>

<script setup>
import { ref, inject } from 'vue'

const member = ref({})

const error = ref('')
import { useRoute, useRouter } from 'vue-router'
const route = useRoute()
const router = useRouter()
console.log('member modify form', route.params)
import { memberAi } from '@/axios'
const getUserDetail = async () => {
  const response = await memberAi.get(`/api/v1/members/${route.params.email}`)
  member.value = response.data.data.result
}
getUserDetail()
// TODO: 03-6. 다음 부분을 memberStore 사용으로 변경하세요.
const globalStatus = inject('globalStatus')
const modifyMember = async () => {
  try {
    await memberAi({
      url: '/api/v1/members',
      method: 'put',
      data: member.value,
    })
    alert('수정되었습니다.')
   if (member.value.email === globalStatus.value.loginUser.email) {
     globalStatus.value.loginUser = member.value
   }

    // END
    router.push({ name: 'memberDetail', query: { email: member.value.email } })
  } catch (e) {
    console.log(e)
  }
}
</script>

<style lang="scss" scoped></style>
