<template>
  <div class="container mt-5">
    <div class="row">
      <MemberDetailInfo :member="member" @profile-update="profileUpdate" />
      <MemberDetailAddress :member="member" @address-update="addressUpdate" />
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import MemberDetailInfo from '@/components/member/MemberDetailInfo.vue'
import MemberDetailAddress from '@/components/member/MemberDetailAddress.vue'

const member = ref({})

const addressUpdate = (addresses) => {
  member.value.addresses = addresses
}
const profileUpdate = (profile) => {
  member.value.profile = profile
}
import { useRoute, onBeforeRouteUpdate } from 'vue-router'
const route = useRoute()
console.log(route.params)

import { memberAi } from '@/axios'
const search = async (email) => {
  try {
    const response = await memberAi({
      url: `/api/v1/members/${email}`,
      method: 'get',
    })
    member.value = response.data.data.result
    console.log('member 상세: ', member.value.addresses)
  } catch (e) {
    console.log(e)
  }
}
search(route.params.email)

onBeforeRouteUpdate((to) => {
  search(to.params.email)
})
</script>

<style scoped></style>
