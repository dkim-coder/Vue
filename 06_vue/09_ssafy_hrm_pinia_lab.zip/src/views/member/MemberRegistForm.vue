<template>
  <div class="container">
    <h1>회원가입</h1>
    <form action="${root}/member/regist-member" method="post" class="m-3">
      <div class="mb-3 row">
        <label for="name" class="col-sm-2 col-form-label">이름</label>
        <div class="col-sm-10">
          <input
            type="text"
            name="name"
            id="name"
            class="form-control"
            required
            v-model="member.name"
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="email" class="col-sm-2 col-form-label">이메일</label>
        <div class="col-sm-10">
          <input
            type="email"
            name="email"
            id="email"
            class="form-control"
            required
            v-model="member.email"
            @input="checkEmail"
            :class="{ 'is-valid': canUse === 'true', 'is-invalid': canUse === 'false' }"
          />
          <div class="invalid-feedback">이미 사용중인 email입니다.</div>
        </div>
      </div>

      <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">비밀번호</label>
        <div class="col-sm-10">
          <input
            type="password"
            name="password"
            id="password"
            class="form-control"
            required
            v-model="member.password"
          />
        </div>
      </div>

      <button type="submit" class="btn btn-primary" @click.prevent="registMember">등록</button>
    </form>

    <div class="alert alert-danger" role="alert" v-if="error">{{ error }}</div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
const member = ref({}) // Member 관리
const error = ref('') // error 관리
const canUse = ref('') // email 중복 관리 '', 'true', 'false' 3가지 값이 필요!

import { memberAiNoAuth } from '@/axios'
const checkEmail = async () => {
  try {
    const response = await memberAiNoAuth({
      url: '/member/checkEmail',
      method: 'get',
      params: member.value,
    })
    // 표시안하거나 is-valid, is-invalid 한 3가지 상태를 처리하기 위해 문자열로..
    canUse.value = response.data.canUse + ''
  } catch (e) {
    const message = e.response.data.error
    if (message.includes('Duplicate entry')) {
      error.value = '이메일이 중복되었습니다.'
    }
  }
}

const registMember = async () => {
  try {
    await memberAiNoAuth({
      url: '/api/v1/members',
      method: 'post',
      data: member.value,
    })
    alert('회원 가입 되었습니다. 로그인 후 사용하세요.')
    member.value = {}
    canUse.value = ''
  } catch (e) {
    const message = e.response.data.error
    if (message.includes('Duplicate entry')) {
      error.value = '이메일이 중복되었습니다.'
    }
  }
}
</script>

<style scoped></style>
