<template>
  <tr>
    <td>{{ member.mno }}</td>
    <td>{{ member.name }}</td>
    <td>
      <a :href="'/auth/member-detail?email=' + member.email" @click.prevent="memberDetail">{{
        member.email
      }}</a>
    </td>
  </tr>
</template>

<script setup>
import { useRouter } from 'vue-router'
const router = useRouter()
const props = defineProps({
  member: {
    type: Object,
    required: true,
  },
})
const memberDetail = () => {
  router.push({ name: 'memberDetail', params: { email: props.member.email } })
}
</script>

<style lang="scss" scoped></style>
