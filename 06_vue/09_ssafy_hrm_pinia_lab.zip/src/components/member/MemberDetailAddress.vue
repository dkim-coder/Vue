<template>
  <div class="col-md-7">
    <div class="card">
      <div class="card-header">
        <h4>주소 정보</h4>
      </div>
      <div class="card-body">
        <table class="table table-bordered" id="table-user-address">
          <thead>
            <tr>
              <th>주소 제목</th>
              <th>주소</th>
              <th>상세 주소</th>
              <th>편집</th>
            </tr>
          </thead>
          <tbody id="address-body">
            <tr v-for="(item, idx) in member.addresses" :key="idx">
              <td>{{ item.title }}</td>
              <td>{{ item.address }}</td>
              <td>{{ item.detailAddress }}</td>
              <td>
                <button class="btn btn-danger" @click="deleteAddress(item.ano)">삭제</button>
              </td>
            </tr>
          </tbody>
        </table>
        <MemberDetailAddressMap :member="member" />
        <hr />
        <form id="formAddressAdd">
          <fieldset class="row g-3">
            <!-- address 등록용 -->
            <input type="hidden" name="mno" :value="member.mno" />
            <!-- member detail 조회용 -->
            <input type="hidden" name="email" :value="member.email" />
            <input type="hidden" name="x" id="x" />
            <input type="hidden" name="y" id="y" />
            <div class="col-md-2">
              <label for="addr_title" class="form-label">제목</label>
              <input
                type="text"
                class="form-control"
                id="title"
                name="title"
                required
                v-model="address.title"
              />
            </div>
            <div class="col-md-5">
              <label for="addr_main" class="form-label">주소</label>
              <input
                type="text"
                class="form-control"
                id="address"
                name="address"
                required
                v-model="address.address"
              />
            </div>
            <div class="col-md-5">
              <label for="addr_detail" class="form-label">상세주소</label>
              <input
                type="text"
                class="form-control"
                id="detailAddress"
                name="detailAddress"
                required
                v-model="address.detailAddress"
              />
            </div>
            <div class="col-12 text-end">
              <button
                type="button"
                class="btn btn-primary"
                :data-mno="member.mno"
                id="btn-address-add"
                @click="addressInsert"
              >
                추가
              </button>
            </div>
          </fieldset>
        </form>
      </div>
    </div>
  </div>
  <div class="alert alert-danger" role="alert" v-if="error">{{ error }}</div>
</template>

<script setup>
import { ref } from 'vue'
const props = defineProps({
  member: Object,
})
import MemberDetailAddressMap from '@/components/member/MemberDetailAddressMap.vue'
const error = ref('')
const address = ref({
  title: '테스트',
  address: '경상북도 울릉군 울릉읍',
  detailAddress: '독도 안용복길 3',
})

const emit = defineEmits(['address-update'])
import { memberAi, memberAiNoAuth } from '@/axios'
const deleteAddress = async (ano) => {
  if (confirm('정말 삭제하시겠습니까?')) {
    const response = await memberAi({
      url: `/api/v1/members/${props.member.email}/addresses/${ano}`,
      method: 'delete',
    })
    emit('address-update', response.data.data.result)
  }
}

const addrToCoords = async () => {
  try {
    const response = await memberAiNoAuth({
      url: 'https://dapi.kakao.com/v2/local/search/address.json',
      params: { query: `${address.value.address} ${address.value.detailAddress}` },
      headers: { Authorization: `KakaoAK ${import.meta.env.VITE_KAKAO_REST_KEY}` },
    })
    if (response.data.documents.length > 0) {
      return [response.data.documents[0].x, response.data.documents[0].y]
    }
  } catch (e) {
    console.log(e)
  }
}

const addressInsert = async () => {
  const coords = await addrToCoords()
  if (!coords) {
    alert('주소를 변환할 수 없습니다.')
    return
  }
  address.value.x = coords[0]
  address.value.y = coords[1]
  try {
    address.value.mno = props.member.mno
    const response = await memberAi({
      url: `/api/v1/members/${props.member.email}/addresses`,
      method: 'post',
      data: address.value,
    })
    emit('address-update', response.data.data.result)
    // address.value = {}
  } catch (e) {
    console.log(e)
  }
}
</script>

<style scoped>
th:nth-child(1) {
  width: 80px;
}

th:nth-child(2) {
  width: 50%;
}

th:nth-child(4) {
  width: 75px;
}

input[type='text'] {
  width: 100%;
}

#map {
  width: 100%;
  height: 300px;
}
</style>
