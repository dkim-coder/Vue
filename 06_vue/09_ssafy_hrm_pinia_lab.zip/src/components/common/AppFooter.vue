<template>
  <div class="container">
    <hr />
    <div class="text-center">ver HRM Axios</div>
  </div>
</template>

<script setup></script>

<style scoped></style>
