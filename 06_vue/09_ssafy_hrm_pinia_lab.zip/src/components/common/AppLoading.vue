<template>
  <dialog ref="loadingDialog">
    <img src="@/assets/img/loading.png" alt="" />
  </dialog>
</template>

<script setup>
// TODO: 04-2. store의 상태에 따라서 dialog를 보여줄 수 있도록 처리해보자.

// END
</script>

<style scoped></style>
