<template>
  <div class="container">
    <h1>login</h1>
    <form action="${root }/member/login" method="post" class="m-3" @submit.prevent="login">
      <div class="mb-3 row">
        <label for="email" class="col-sm-2 col-form-label">이메일</label>
        <div class="col-sm-10">
          <input
            type="email"
            id="email"
            v-model="member.email"
            placeholder="email 입력"
            class="form-control"
            required
          />
        </div>
      </div>

      <div class="mb-3 row">
        <label for="password" class="col-sm-2 col-form-label">비밀번호</label>
        <div class="col-sm-10">
          <input
            type="password"
            name="current_password"
            id="current_password"
            class="form-control"
            required
            v-model="member.password"
          />
        </div>
      </div>
      <div class="d-flex justify-content-end align-items-center">
        <div class="form-check">
          <input
            type="checkbox"
            v-model="saveEmail"
            name="remember-me"
            id="remember-me"
            class="form-check-input"
          />
          <label for="remember-me" class="form-check-label">로그인 유지</label>
        </div>
        <button type="submit" class="btn btn-primary ms-3" @click.prevent="login">로그인</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
const router = useRouter()

// 멤버 관리
const member = ref({
  email: localStorage.getItem('email'),
})
// 이메일 저장 관리
const saveEmail = ref(member.value.email ? true : false)

import { useMemberStore } from '@/store/member'
const memberStore = useMemberStore()
const login = async () => {
  try {
    await memberStore.login(member.value)
  } catch (e) {
    console.log(e)
    alert(e?.response?.data?.message)
  }
  if (saveEmail.value) {
    localStorage.setItem('email', member.value.email)
  } else {
    localStorage.removeItem('email')
  }
  router.push({ name: 'home' })
}
</script>

<style scoped></style>
