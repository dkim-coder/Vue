<template>
  <div class="container">
    <h1>MainView</h1>
    <div>
      component 생성 후 지금까지: {{ memberStore?.tokenTime }}, token 상태:
      {{ memberStore?.tokenStatus }}
      {{ count }}, {{ message }}
    </div>
  </div>
</template>

<script setup>
import { useMemberStore } from '@/store/member'
const memberStore = useMemberStore()
console.log(memberStore.tokenTime)
import { ref, onMounted, onUpdated } from 'vue'
const count = ref(0)
const message = ref(null)

onMounted(() => {
  console.log('mounted')
  message.value = 'mounted!'
})

onUpdated(() => {
  console.log('updated call')
  message.value = 'updated!'
})
</script>

<style lang="scss" scoped></style>
