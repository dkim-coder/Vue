import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import router from '@/router'
import { memberAi } from '@/axios'
import { jwtDecode } from 'jwt-decode'
export const useMemberStore = defineStore(
  'member',
  () => {
    const _isLoggedIn = ref(false)
    const _loginUser = ref({})

    const isLoggedIn = computed(() => _isLoggedIn.value)
    const loginUser = computed(() => _loginUser.value)

    const login = async ({ email, password }) => {
      // TODO: 02-1. memberAi를 통해서 로그인 하고 token을 처리해보자.
      if (email === 'admin@ssafy.com' && password === '1234') {
        _loginUser.value = { email, name: '김싸피', role: 'ADMIN' }
        _isLoggedIn.value = true
      } else {
        throw 'id/pass 확인'
      }
      //  서버의 응답을 이용해 _isLoggedIn, _loginUser, _tokens 정보를 갱신한다.

      // END
    }

    const logout = async () => {
      // TODO: 02-2. logout 처리해보자.
      //  목적은 refresh token 전송. 이미 access token은 만료되었을 수도 있으므로 검증은 패스~
      _loginUser.value = {}
      _isLoggedIn.value = false
      router.push({ name: 'home' })

      //END
    }

    // TODO: 01-1. _tokens를 선언하고 getter를 제공하자.

    // END

    // TODO: 02-3. refresh를 호출해서 새로운 token을 받아온다.

    // END

    // token의 만료 상태를 확인하기 위한 부분----------
    const tokenTime = ref(0)
    let intervalId
    const resetTokenTime = () => {
      window.clearInterval(intervalId)
      tokenTime.value = 0
      intervalId = setInterval(() => {
        tokenTime.value++
      }, 1000)
    }

    const tokenStatus = computed(() => {
      if (!_tokens.value.refreshToken) {
        window.clearInterval(intervalId)
        tokenTime.value = 0
        return '로그아웃 상태'
      }
      if (tokenTime.value > 120) {
        return 'refresh token 만료'
      } else if (tokenTime.value > 60) {
        return 'access token 만료'
      } else {
        return 'token 유효'
      }
    })
    // token의 만료 상태를 확인하기 위한 부분----------

    // TODO: 공개할 기능들을 등록해주자.
     return { isLoggedIn, loginUser, login, logout, _loginUser, _isLoggedIn, tokenTime, tokenStatus }

    // END
  },
  {
    persist: { storage: sessionStorage },
  },
)
