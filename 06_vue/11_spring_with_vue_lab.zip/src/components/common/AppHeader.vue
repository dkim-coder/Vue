<template>
  <div class="container">
    <header class="d-flex justify-content-center my-5 align-items-center">
      <h1 class="text-center">Welcome To</h1>
      <img src="@/assets/img/ssafy_logo.png" id="logo" />
    </header>
    <div class="d-flex justify-content-end">
      <RouterLink :to="{ name: 'home' }" class="mx-3">홈으로</RouterLink>
      |
      <RouterLink :to="{ name: 'memberList', query: { currentPage: 1 } }" class="mx-3"
        >멤버목록</RouterLink
      >
      |
      <template v-if="!memberStore.isLoggedIn">
        <RouterLink :to="{ name: 'loginForm' }" class="mx-3">로그인</RouterLink> |
        <RouterLink :to="{ name: 'registMemberForm' }" class="mx-3">회원가입</RouterLink>
      </template>
      <template v-if="memberStore.isLoggedIn">
        <RouterLink
          :to="{ name: 'memberDetail', params: { email: memberStore.loginUser.email } }"
          class="mx-3"
          >{{ memberStore.loginUser.name }}</RouterLink
        >
        |
        <a href="${root }/member/logout" class="mx-3" @click.prevent="logout">로그아웃</a>
      </template>
    </div>
    <hr />
  </div>
</template>

<script setup>
import { useMemberStore } from '@/store/member'
const memberStore = useMemberStore()
const logout = () => {
  memberStore.logout()
}
</script>

<style scoped>
header > #logo {
  width: 90px;
  margin-bottom: 8px;
  margin-left: 10px;
}

header > h1 {
  line-height: 50px;
  display: inline-block;
  height: 50px;
}
</style>
