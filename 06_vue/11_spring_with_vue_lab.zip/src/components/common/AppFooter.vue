<template>
  <div class="container">
    <hr />
    <div class="text-center">ver HRM with Spring</div>
  </div>
</template>

<script setup></script>

<style scoped></style>
