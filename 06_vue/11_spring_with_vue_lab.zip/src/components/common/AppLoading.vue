<template>
  <dialog ref="loadingDialog">
    <img src="@/assets/img/loading.png" alt="" />
  </dialog>
</template>

<script setup>
import { watchEffect, useTemplateRef } from 'vue'
import { useCommonStore } from '@/store/common'
const commonStore = useCommonStore()
const loadingDialog = useTemplateRef('loadingDialog')
watchEffect(() => {
  if (commonStore.hasMoreTask) {
    // immediate 시점에 loadingDialog의 value가 없을 수도 있음.
    loadingDialog.value?.showModal()
  } else {
    loadingDialog.value?.close()
  }
})
</script>

<style scoped></style>
