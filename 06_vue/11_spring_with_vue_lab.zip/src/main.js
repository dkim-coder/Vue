import { createApp } from 'vue'
import App from './App.vue'

const app = createApp(App)

import 'bootstrap/dist/css/bootstrap.min.css'
import 'bootstrap/dist/js/bootstrap.min.js'

import { useKakao } from 'vue3-kakao-maps'
useKakao(import.meta.env.VITE_KAKAO_JS_KEY, ['clusterer', 'services', 'drawing'])

import { createPinia } from 'pinia'
import piniaPluginPersistedState from 'pinia-plugin-persistedstate'
const pinia = createPinia()
pinia.use(piniaPluginPersistedState)
app.use(pinia)

import router from './router'
app.use(router)
app.mount('#app')
