import { createRouter, createWebHistory } from 'vue-router'
import MainView from '@/views/MainView.vue'
const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: () => MainView,
    },
    {
      path: '/member',
      children: [
        {
          path: 'login-form',
          name: 'loginForm',
          component: () => import('@/views/member/LoginForm.vue'),
        },
        {
          path: 'regist-member-form',
          name: 'registMemberForm',
          component: () => import('@/views/member/MemberRegistForm.vue'),
        },
      ],
    },
    {
      path: '/auth',
      meta: { requireAuth: true },
      children: [
        {
          path: 'member-list',
          name: 'memberList',
          component: () => import('@/views/member/MemberList.vue'),
        },
        {
          path: 'member-detail/:email',
          name: 'memberDetail',
          component: () => import('@/views/member/MemberDetail.vue'),
        },
        {
          path: 'member-modify-form/:email',
          name: 'memberModifyForm',
          component: () => import('@/views/member/MemberModifyForm.vue'),
        },
      ],
    },
    // TODO: 04. 404를 처리하기 위한 경로를 등록해보자.
