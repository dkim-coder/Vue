// import './assets/main.css'

import { createApp } from 'vue';
//import App from './App.vue'
import App from './book/01_Template.vue';
//import App from './book/02_vbind_simple.vue';
//import App from './book/03_vbind_classes.vue';
//ximport App from './book/04_vbind_inline_styles.vue';
//import App from './book/05_event_hadling.vue'
//import App from './book/06_form_input_bindings.vue'
//import App from './book/07_vmodel.vue'
//import App from './example/ex_01_temp.vue'
//import App from './example/ex_02_reactivity.vue';
//import App from './example/ex_03_vbind.vue';
//import App from './example/ex_04_style.vue';
//import App from './example/ex_05_model.vue';
//import App from './example/ex_06_event_basic.vue';
//import App from './example/ex_07_event_modifier.vue';

createApp(App).mount('#app');
