<script setup>
// TODO: 01. message라는 이름으로 '<h1>Hi Vue</h1>'를 반응형으로 설정하세요.
</script>

<template>
  <ul>
    <!-- TODO: 02. vue의 다양한 문자열 보간 방식을 테스트하시오. -->
    <!--  {{  }} 활용: '오늘의 메시지 : '라고 출력하세요.-->
    <!--  html 형태로 출력하세요.-->
    <!--  text 형태로 출력하세요. 단 대문자로 처리한다.-->
    <!--  text 형태로 출력하세요. 단 출력 후 반응성을 삭제한다.-->

    <!-- END -->
  </ul>
</template>

<style scoped></style>
