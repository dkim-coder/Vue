<template>
  <div class="container">
    <!--TODO: 02-2. vuetify의 component를 사용해보자.-->

    <!--END-->
    <!--TODO: 03-3. kakao map을 사용해보자.-->

    <!--END-->
  </div>
</template>

<script setup>
// TODO: 03-2. kakao map을 사용해보자.

// END
</script>

<style lang="scss" scoped></style>
