package com.ssafy.live.ai.tools;

import java.util.List;

import org.springframework.ai.tool.annotation.Tool;
import org.springframework.ai.tool.annotation.ToolParam;
import org.springframework.stereotype.Component;

import com.ssafy.live.model.dto.Member;
import com.ssafy.live.model.dto.Page;
import com.ssafy.live.model.dto.SearchCondition;
import com.ssafy.live.model.service.MemberService;

import lombok.RequiredArgsConstructor;

@Component
@RequiredArgsConstructor
public class MemberTools {
    private final MemberService mService;

    @Tool(description = "email을 사용하는 사용자의 정보를 반환한다.")
    public Member selectDetail(String email) {
        return mService.selectDetail(email);
    }

    @Tool(description = "Member 정보를 저장한다.")
    public int registMember(@ToolParam(description = "저장할 회원의 정보로 name, email, password만 갖는다.") Member member) {
        return mService.registMember(member);
    }

    @Tool(description = "전체 사용자의 목록을 반환한다.")
    public List<Member> searchAll() {
        return mService.searchAll();
    }

    @Tool(description = "검색 조건인 SearchCondition에 해당하는 데이터를 반환한다.1페이지 당 5개의 정보를 출력한다.")
    public Page<Member> search(@ToolParam(description = "검색 조건으로 key, word, currentPage를 속성으로 갖는다.") SearchCondition condition) {
        return mService.search(condition);
    }

    @Tool(description = "주어진 mno에 해당하는 Member를 삭제한다.")
    public void delete(int mno) {
        mService.delete(mno);
    }

    @Tool(description = "전달받은 Member 정보로 회원의 정보를 업데이트 한다.")
    public void update(Member member) {
        mService.update(member);
    }

    @Tool(description = "email에 해당하는 사용자의 profile 정보를 업데이트 한다.")
    public void updateProfile(String email, byte[] profile) {
        mService.updateProfile(email, profile);
    }
}
