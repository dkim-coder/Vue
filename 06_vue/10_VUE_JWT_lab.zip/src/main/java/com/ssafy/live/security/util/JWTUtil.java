package com.ssafy.live.security.util;

import java.util.Arrays;
import java.util.Date;
import java.util.Map;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.ssafy.live.model.dto.Member;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtParser;
import io.jsonwebtoken.Jwts;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class JWTUtil {
    private final SecretKey key;

    public JWTUtil() {
        key = Jwts.SIG.HS256.key().build(); // secret key
        log.debug("jwt secret key: {}", Arrays.toString(key.getEncoded()));
    }

    @Value("${ssafy.jwt.access-expmin}")
    private long accessExpMin;

    @Value("${ssafy.jwt.refresh-expmin}")
    private long refreshExpMin;

    public String createAccessToken(Member member) {
        // null 값을 직렬화 시킬 수 없다.
        if (member.getRole() == null) {
            member.setRole("USER");
        }
        return create("accessToken", accessExpMin,
                Map.of("email", member.getEmail(), "name", member.getName(), "role", member.getRole()));
    }

    public String createRefreshToken(Member member) {
        return create("refreshToken", refreshExpMin, Map.of("email", member.getEmail()));
    }

    /**
     * JWT를 반환한다.
     * 
     * @param subject
     *            token의 제목(accessToken, refreshToken)
     * @param expireMin
     * @param member
     *            회원 정보
     * @return
     */
    public String create(String subject, long expireMin, Map<String, Object> claims) {

        Date expireDate = new Date(System.currentTimeMillis() + 1000 * 60 * expireMin);
        // TODO: 03-1. JWT를 생성해서 반환하세요.
        //  claim에는 email, name, role을 담고, 만료일은 expireDate로 설정하세요.
         return null;

        // END
    }

    /**
     * 토큰 검증 및 claim 정보 반환
     * 
     * @param jwt
     * @return
     * @throws ExpireJwtException:
     *             형식은 적합하지만 토큰의 유효기간이 지난 경우
     *             MalformedJwtException: 형식이 잘못된 토큰을 이용하려는 경우
     *             SignatureException: 훼손된 토큰을 이용하려는 경우
     */
    public Map<String, Object> getClaims(String jwt) {
        // TODO: 03-2. JWT토큰을 검증하고 claim 정보를 반환하는 코드를 살펴보세요.
         return null;

        // END
    }
}
