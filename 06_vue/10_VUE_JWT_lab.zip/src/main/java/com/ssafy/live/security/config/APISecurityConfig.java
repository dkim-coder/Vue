package com.ssafy.live.security.config;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import com.ssafy.live.security.filter.JWTAuthenticationFilter;
import com.ssafy.live.security.filter.JWTVerificationFilter;
import com.ssafy.live.security.service.CustomUserDetailService;

@Configuration
public class APISecurityConfig {

    @Bean
    // Spring Security 5.4 이상에서 AuthenticationManager를 Bean으로 사용하려면 명시적 등록 필요
    AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {

        return authConfig.getAuthenticationManager();
    }

    // TODO: 06-1. SecurityFilterChain을 생성한다.
    @Bean
    @Order(1) // 낮을 수록 우선순위가 높음. 생략 시 가장 낮음
    public SecurityFilterChain apiSecurityFilterChain(
            HttpSecurity http,
            CustomUserDetailService userDetailsService,
            JWTAuthenticationFilter authFilter,
            JWTVerificationFilter jwtVerifyFilter,
            @Qualifier("corsConfigurationSource") CorsConfigurationSource corsConfig)
            throws Exception {

        http.securityMatcher("/api/**") // SecurityFilterChain의 동작 범위 설정
                .cors(cors -> cors.configurationSource(corsConfig))  // 명시적 CORS 설정 사용
                .userDetailsService(userDetailsService)
                .csrf(csrf -> csrf.disable())// Csrf 설정 무력화
                .sessionManagement(// 세션 설정 - 세션 사용하지 않음
                        session -> session
                                .sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests( // 인가 정보 확인이 필요한 경로 설정
                        authorize -> authorize
                                .requestMatchers("/api/v1/etc/**", "/api/auth/**").permitAll()   // 기타 경로와 인증 처리 경로는 허용
                                .requestMatchers(HttpMethod.POST, "/api/v1/members").permitAll() // /api/v1/members 자체는 허용
                                .anyRequest().authenticated())
                // Filter의 위치 지정
                .addFilterBefore(jwtVerifyFilter, UsernamePasswordAuthenticationFilter.class)
                .addFilterAt(authFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    // TODO: 06-2. Filter 수준에서 동작하기 위한 CorsConfigurationSource를 구성하고 적용하자.
    // @@COMMENT: WebMvcConfigurer는 cors 설정은 무의미
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Arrays.asList("*"));
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(Arrays.asList("*"));

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", configuration);
        source.registerCorsConfiguration("/member/checkEmail", configuration);

        return source;
    }
}
